
var ispause=false;
function Start ()
 {

}
function menu()
{
  Application.LoadLevel("menu");
}

function Update () {

}
