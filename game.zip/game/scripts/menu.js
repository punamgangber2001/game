﻿
function Start () {

}

function ChangeScene()
{
Application.LoadLevel("city");
}
function back()
{
Application.LoadLevel("menu");
}

function Update () {

}

function Quit()
{
	Application.Quit();
}
